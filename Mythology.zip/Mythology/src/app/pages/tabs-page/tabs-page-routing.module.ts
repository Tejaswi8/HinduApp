import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs-page';
import { bagPage } from '../bag/bag';
import {ramayanamPage} from '../ramayanam/ramayanam'

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'about',
        children: [
          {
            path: '',
            loadChildren: () => import('../about/about.module').then(m => m.AboutModule)
          }
        ]
      },
      {
        path: 'bag',
        children: [
          {
            path: '',
            component: bagPage,
          },
          {
            path: 'cart/:cartId',
            loadChildren: () => import('../cart-detail/cart-detail.module').then(m => m.cartDetailModule)
          }
        ]
      },
      {
        path: 'ramayanam',
        children: [
          {
            path: '',
            component: ramayanamPage,
          }
          // {
          //   path: 'ramayanam/:ramayanamId',
          //   loadChildren: () => import('../cart-detail/cart-detail.module').then(m => m.cartDetailModule)
          // }
        ]
      },
      {
        path: 'speakers',
        children: [
          {
            path: '',
            loadChildren: () => import('../speaker-list/speaker-list.module').then(m => m.SpeakerListModule)
          },
          {
            path: 'cart/:cartId',
            loadChildren: () => import('../cart-detail/cart-detail.module').then(m => m.cartDetailModule)
          },
          {
            path: 'speaker-details/:speakerId',
            loadChildren: () => import('../speaker-detail/speaker-detail.module').then(m => m.SpeakerDetailModule)
          }
        ]
      },
      {
        path: 'map',
        children: [
          {
            path: '',
            loadChildren: () => import('../map/map.module').then(m => m.MapModule)
          }
        ]
      },
      {
        path: '',
        redirectTo: '/app/tabs/about',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/app/tabs/about',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule { }

