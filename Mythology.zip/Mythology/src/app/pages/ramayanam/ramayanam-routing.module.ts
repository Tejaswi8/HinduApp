import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ramayanamPage } from './ramayanam';

const routes: Routes = [
  {
    path: '',
    component: ramayanamPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ramayanamPageRoutingModule { }
