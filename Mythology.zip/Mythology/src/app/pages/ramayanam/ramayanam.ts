import { Component, ViewChild, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, IonList, LoadingController, ModalController, ToastController, Config } from '@ionic/angular';

// import { ramayanamFilterPage } from '../ramayanam-filter/ramayanam-filter';
import { ConferenceData } from '../../providers/conference-data';
import { UserData } from '../../providers/user-data';

@Component({
  selector: 'page-ramayanam',
  templateUrl: 'ramayanam.html',
  styleUrls: ['./ramayanam.scss'],
})
export class ramayanamPage implements OnInit {
  // Gets a reference to the list element
  // @ViewChild('ramayanamList', { static: true }) ramayanamList: IonList;

  ios: boolean;
  dayIndex = 0;
  queryText = '';
  segment = 'all';
  excludeTracks: any = [];
  // shownramayanams: any = [];
  groups: any = [];
  confDate: string;

  constructor(
    public alertCtrl: AlertController,
    public confData: ConferenceData,
    public loadingCtrl: LoadingController,
    public modalCtrl: ModalController,
    public router: Router,
    public toastCtrl: ToastController,
    public user: UserData,
    public config: Config
  ) { }

  ngOnInit() {
    // this.updateramayanam();

    this.ios = this.config.get('mode') === 'ios';
  }

  // updateramayanam() {
  //   // Close any open sliding items when the ramayanam updates
  //   if (this.ramayanamList) {
  //     this.ramayanamList.closeSlidingItems();
  //   }

  //   this.confData.getTimeline(this.dayIndex, this.queryText, this.excludeTracks, this.segment).subscribe((data: any) => {
  //     this.shownramayanams = data.shownramayanams;
  //     this.groups = data.groups;
  //   });
  // }

//   async presentFilter() {
//     const modal = await this.modalCtrl.create({
//       component: ramayanamFilterPage,
//       componentProps: { excludedTracks: this.excludeTracks }
//     });
//     await modal.present();

//     const { data } = await modal.onWillDismiss();
//     if (data) {
//       this.excludeTracks = data;
//       this.updateramayanam();
//     }
//   }

  // async addFavorite(slidingItem: HTMLIonItemSlidingElement, ramayanamData: any) {
  //   if (this.user.hasFavorite(ramayanamData.name)) {
  //     // woops, they already favorited it! What shall we do!?
  //     // prompt them to remove it
  //     this.removeFavorite(slidingItem, ramayanamData, 'Favorite already added');
  //   } else {
  //     // remember this ramayanam as a user favorite
  //     this.user.addFavorite(ramayanamData.name);

  //     // create an alert instance
  //     const alert = await this.alertCtrl.create({
  //       header: 'Favorite Added',
  //       buttons: [{
  //         text: 'OK',
  //         handler: () => {
  //           // close the sliding item
  //           slidingItem.close();
  //         }
  //       }]
  //     });
  //     // now present the alert on top of all other content
  //     await alert.present();
  //   }

  // }

  // async removeFavorite(slidingItem: HTMLIonItemSlidingElement, ramayanamData: any, title: string) {
  //   const alert = await this.alertCtrl.create({
  //     header: title,
  //     message: 'Would you like to remove this ramayanam from your favorites?',
  //     buttons: [
  //       {
  //         text: 'Cancel',
  //         handler: () => {
  //           // they clicked the cancel button, do not remove the ramayanam
  //           // close the sliding item and hide the option buttons
  //           slidingItem.close();
  //         }
  //       },
  //       {
  //         text: 'Remove',
  //         handler: () => {
  //           // they want to remove this ramayanam from their favorites
  //           this.user.removeFavorite(ramayanamData.name);
  //           this.updateramayanam();

  //           // close the sliding item and hide the option buttons
  //           slidingItem.close();
  //         }
  //       }
  //     ]
  //   });
  //   // now present the alert on top of all other content
  //   await alert.present();
  // }

  async openSocial(network: string, fab: HTMLIonFabElement) {
    const loading = await this.loadingCtrl.create({
      message: `Posting to ${network}`,
      duration: (Math.random() * 1000) + 500
    });
    await loading.present();
    await loading.onWillDismiss();
    fab.close();
  }
}
