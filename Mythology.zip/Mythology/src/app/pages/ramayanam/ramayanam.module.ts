import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { ramayanamPage } from './ramayanam';
// import { ramayanamFilterPage } from '../ramayanam-filter/ramayanam-filter';
import { ramayanamPageRoutingModule } from './ramayanam-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ramayanamPageRoutingModule
  ],
  declarations: [
    ramayanamPage,
    // ramayanamFilterPage
  ],
  entryComponents: [
   // ramayanamFilterPage
  ]
})
export class ramayanamModule { }
