import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { bagPage } from './bag';

const routes: Routes = [
  {
    path: '',
    component: bagPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class bagPageRoutingModule { }
