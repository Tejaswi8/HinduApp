import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';

import { bagPage } from './bag';
import { bagFilterPage } from '../bag-filter/bag-filter';
import { bagPageRoutingModule } from './bag-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    bagPageRoutingModule
  ],
  declarations: [
    bagPage,
    bagFilterPage
  ],
  entryComponents: [
    bagFilterPage
  ]
})
export class bagModule { }
