import { Component } from '@angular/core';

import { ConferenceData } from '../../providers/conference-data';
import { ActivatedRoute } from '@angular/router';
import { UserData } from '../../providers/user-data';

@Component({
  selector: 'page-cart-detail',
  styleUrls: ['./cart-detail.scss'],
  templateUrl: 'cart-detail.html'
})
export class cartDetailPage {
  cart: any;
  isFavorite = false;
  defaultHref = '';

  constructor(
    private dataProvider: ConferenceData,
    private userProvider: UserData,
    private route: ActivatedRoute
  ) { }

  ionViewWillEnter() {
    this.dataProvider.load().subscribe((data: any) => {
      if (data && data.bag && data.bag[0] && data.bag[0].groups) {
        const cartId = this.route.snapshot.paramMap.get('cartId');
        for (const group of data.bag[0].groups) {
          if (group && group.carts) {
            for (const cart of group.carts) {
              if (cart && cart.id === cartId) {
                this.cart = cart;

                this.isFavorite = this.userProvider.hasFavorite(
                  this.cart.name
                );

                break;
              }
            }
          }
        }
      }
    });
  }

  ionViewDidEnter() {
    this.defaultHref = `/app/tabs/bag`;
  }

  cartClick(item: string) {
    console.log('Clicked', item);
  }

  toggleFavorite() {
    if (this.userProvider.hasFavorite(this.cart.name)) {
      this.userProvider.removeFavorite(this.cart.name);
      this.isFavorite = false;
    } else {
      this.userProvider.addFavorite(this.cart.name);
      this.isFavorite = true;
    }
  }

  sharecart() {
    console.log('Clicked share cart');
  }
}
