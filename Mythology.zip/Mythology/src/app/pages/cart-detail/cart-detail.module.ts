import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { cartDetailPage } from './cart-detail';
import { cartDetailPageRoutingModule } from './cart-detail-routing.module';
import { IonicModule } from '@ionic/angular';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    cartDetailPageRoutingModule
  ],
  declarations: [
    cartDetailPage,
  ]
})
export class cartDetailModule { }
