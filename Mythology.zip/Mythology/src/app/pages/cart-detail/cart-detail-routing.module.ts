import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { cartDetailPage } from './cart-detail';

const routes: Routes = [
  {
    path: '',
    component: cartDetailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class cartDetailPageRoutingModule { }
